# nn-ik - ANN-based inverse kinematics coursework

Project structure and how to run each part (Python 3, Webots R2023b;
libraries used: standard library + numpy + scikit-learn only).

## Task 1.A - Webots controllers

Two arm controllers that accept joint values, move the arm, wait for it
to settle, then signal the supervisor to record the measured TCP:

    controllers/ned_simple/ned_simple.py    (joint_1, joint_2, joint_3 in rad)
    controllers/scara_simple/scara_simple.py(base_arm_motor, arm_motor in rad,
                                             shaft_linear_motor in metres)

Shared supervisor (already referenced by both world files):

    controllers/tcp_pose/tcp_pose.py

Run: open `worlds/articulated.wbt` (Ned) or `worlds/scara.wbt` (SCARA) in
Webots and press play. Joint values come from controllerArgs in the world
file, or from DEFAULT_JOINTS at the top of each controller. The supervisor
appends the measured TCP to `tcp_measurements.csv` in this directory.

## Task 1.B - Forward kinematics (pure Python)

    scripts/fk_ned.py      python fk_ned.py q1 q2 q3      (rad)
    scripts/fk_scara.py    python fk_scara.py q1 q2 q4    (rad, rad, m)

Both print the TCP position in the ARM frame and expose fk() for import.

## Task 1.C - FK verification against Webots

Run the Task 1.A controllers (both arms), then:

    python scripts/compare_fk_webots.py

Compares every row of tcp_measurements.csv against the analytical FK and
reports mean/std/max error in millimetres.

## Task 2 - Dataset generation

Run from the project root (Python 3, no Webots required):

    python scripts/generate_datasets.py --output datasets --seed 42

The script calls the two Task 1.B `fk()` functions and creates 14 CSV files:
`ned_train_N.csv`, `ned_validation_N.csv`, `scara_train_N.csv`, and
`scara_validation_N.csv` for N=1000, 5000, 20000, plus `ned_test.csv` and
`scara_test.csv` (500 rows each). The sizes are total samples before the
80/20 split. Change them with `--sizes 1000 5000 20000` and change the
held-out count with `--test-size 500`. The same seed reproduces the same files.

Each CSV header is `arm,x,y,z,q1_norm,q2_norm,q3_norm`. Coordinates are
metres in the arm's frame; joint targets are scaled to [-1, 1] from the
sampling limits in `generate_datasets.py`. Ned columns q1/q2/q3 represent
joint_1/joint_2/joint_3 (radians); SCARA columns represent base_arm_motor
(radians), arm_motor (radians), shaft_linear_motor (metres). In both arms the
elbow joint is sampled strictly positive. The same limits apply to every
split. `denormalise()` reverses the scaling for later motor commands.

For each arm, every smaller training file is a prefix of its larger training
file; the same applies to validation. Training, validation and test samples
are disjoint, with the test file reserved for Task 4. Run the command yourself
to produce the final coursework data; review the resulting values and sizes.
